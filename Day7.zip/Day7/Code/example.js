//Backtick
console.log("Hellooooo");

let s1 = `Nisha ", ' Mumbai!`;
let s2 = "Web browsers receive HTML documents from a web"
        + "server or from local. Web browsers receive HTML" 
        +" documents from a web server or from local.  Web " 
        +"browsers receive HTML documents from a web server or "
        + "from local. Web browsers receive HTML documents from a web server or from local. Web browsers receive HTML documents from a web server or from local. Web browsers receive HTML documents from a web server or from local. Web browsers receive HTML documents from a web server or from local. ";

let s3 = `Web browsers receive HTML documents from a web server 
            or from local. Web browsers receive HTML documents from a 
            web server or from local. Web browsers receive HTML 
            documents from a web server or from local. Web browsers
             receive HTML documents from a web server or from local. 
             Web browsers receive HTML documents from a web server or 
             from local. Web browsers receive HTML documents from a web 
             server or from local. Web browsers receive HTML documents 
             from a web server or from local. `


let username = "RAHUL"  
let usercity = "Kharghar"           
let mail  = `
    Hello, Mr ${username}!
    Address ${usercity},

    Web browsers receive HTML documents from a web server or from local. 
    Web browsers receive HTML documents from a web server or from local. 
    Web browsers receive HTML documents from a web server or from local. 
    Web browsers receive HTML documents from a web server or from local. 
    Web browsers receive HTML documents from a web server or from local. 
    Web browsers receive HTML documents from a web server or from local. 

    Regards,
    CDAC
`;

